package hello;

public class HelloWorld {

	public static void main(String[] args) {
		foo();
	}
	
	public static void foo() {
		
	}
}
