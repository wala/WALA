
// Worklight comes with the jQuery framework bundled inside. If you do not want to use it, please comment out the line below.
window.$ = WLJQ;

function wlCommonInit(){
	// Common initialization code goes here
}
