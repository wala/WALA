
/* JavaScript content from js/foo.js in folder common */
// Wait for Cordova to load
//
alert("starting");
document.addEventListener("deviceready", onDeviceReady, false);

// Cordova is ready
//
function onDeviceReady() {
    alert("device ready");
    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFS, fail);
}

function gotFS(fileSystem) {
    alert("for file system " + fileSystem);
    fileSystem.root.getFile("location.txt", {create: true, exclusive: false}, gotFileEntry, fail);
}

function gotFileEntry(fileEntry) {

    function loop() {

        function gotFileWriter(writer) {
            
            writer.onwriteend = function(evt) {
                var ft = new FileTransfer(),
                path = fileEntry.fullPath,
                name = fileEntry.name;
                
                ft.upload(path,
                          "http://9.2.43.162/upload.php",
                          function(result) {
                              console.log('Upload success: ' + result.responseCode);
                              console.log(result.bytesSent + ' bytes sent');
                          },
                          function(error) {
                              console.log('Error uploading file ' + path + ': ' + error.code);
                          },
                          { fileKey: "fileName", fileName: name });   
            };
            
            function onSuccess(position) {
                writer.write(
                    'Latitude: ' + position.coords.latitude + '\n' +
                        'Longitude: ' + position.coords.longitude + '\n' +
                        'Altitude: ' + position.coords.altitude + '\n' +
                        'Accuracy: ' + position.coords.accuracy + '\n' +
                        'Altitude Accuracy: ' + position.coords.altitudeAccuracy + '\n' +
                        'Heading: ' + position.coords.heading + '\n' +
                        'Speed: ' + position.coords.speed + '\n' +
                        'Timestamp: ' + position.timestamp + '\n');
            }
            
            navigator.geolocation.getCurrentPosition(onSuccess, fail);
            window.setTimeout(loop, 5000);
        }

        fileEntry.createWriter(gotFileWriter, fail);
    }

    window.setTimeout(loop, 1000);
}

function fail(error) {
	alert('code: '    + error.code    + '\n' +
          'message: ' + error.message + '\n');
}
