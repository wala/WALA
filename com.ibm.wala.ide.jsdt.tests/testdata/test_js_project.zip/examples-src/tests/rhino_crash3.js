function f() {
	switch (0) {
	default:
		break;
	}
	oParsedResponse || 0;
}

f();

