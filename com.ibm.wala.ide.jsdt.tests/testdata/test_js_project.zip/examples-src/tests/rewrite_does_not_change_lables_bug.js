function f(){
	switch (a){
	case b:
		return "wow"
	}
}
f();
