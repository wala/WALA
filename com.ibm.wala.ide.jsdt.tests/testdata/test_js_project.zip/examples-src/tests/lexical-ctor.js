x1 = "a";
x2 = "a";
x3 = "a";
x4 = "a";
x5 = "a";
x6 = "a";
x7 = "a";
x8 = "a";
x9 = "a";
x10 = "a";
x11 = "a";
x12 = "a";
x13 = "a";
x14 = "a";
x15 = "a";
x16 = "a";
x17 = "a";
x18 = "a";
x19 = "a";
x20 = "a";
x21 = "a";
x22 = "a";
x23 = "a";
x24 = "a";
x25 = "a";
x26 = "a";

function foo() {
	var y = x1 +
	x2 +
	x3 +
	x4 +
	x5 +
	x6 +
	x7 +
	x8 +
	x9 +
	x10 +
	x11 +
	x12 +
	x13 +
	x14 +
	x15 +
	x16 +
	x17 +
	x18 +
	x19 +
	x20 +
	x21 +
	x22 +
	x23 +
	x24 +
	x25;
	alert(y);
	x26 = y;
}

new foo();