

(function(x) {
        switch(x) {
            case Ext.Date:
            	return 1;
            	break;
        }
        return -1;
    })(0);

