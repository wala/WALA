var x = {};

var y = x instanceof Object;

var z = x instanceof Function;
