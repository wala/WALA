this.f = function foo() {};

f();