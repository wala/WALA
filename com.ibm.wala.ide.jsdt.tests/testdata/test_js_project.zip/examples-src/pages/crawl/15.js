function changeUrls()
{
	document.links[0].href = "page15.php?a=ok";
}