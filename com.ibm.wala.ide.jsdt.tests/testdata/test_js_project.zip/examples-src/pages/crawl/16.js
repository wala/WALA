function changeUrls()
{
	document.links[0].href = "page16.php?a=ok";
}