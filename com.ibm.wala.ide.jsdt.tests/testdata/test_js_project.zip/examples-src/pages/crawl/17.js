function changeUrls()
{
	document.links[0].href = "page17.php?a=ok";
}