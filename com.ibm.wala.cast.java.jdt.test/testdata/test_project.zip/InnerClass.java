public class InnerClass {
    
    public static void main(String[] args) { new InnerClass().method(); }
    
    public int fromInner(int v) { return v + 1; }
    
    public int fromInner2(int v) { return v + 3; }
    
    public void method() { WhatsIt w = this.new WhatsIt(); }
    
    class WhatsThat {
        private int otherValue;
        
        WhatsThat() {
            super();
            otherValue = 3;
            InnerClass.this.fromInner2(otherValue);
        }
    }
    
    class WhatsIt {
        private int value;
        
        public WhatsIt() {
            super();
            value = 0;
            InnerClass.this.fromInner(value);
            this.anotherMethod();
        }
        
        private NotAgain anotherMethod() { return this.new NotAgain(); }
        
        class NotAgain {
            Object x;
            
            public NotAgain() {
                super();
                x = InnerClass.this.new WhatsThat();
            }
        }
        
    }
    
    
    public InnerClass() { super(); }
}
