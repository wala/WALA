public class InnerClassSuper {
    int x = 5;
    class SuperOuter {
        
        public void test() { System.out.println(x); }
        
        public SuperOuter() { super(); }
    }
    
    
    public static void main(String[] args) { new Sub().new SubInner(); }
    
    public InnerClassSuper() { super(); }
}

class Sub extends InnerClassSuper {
    class SubInner {
        
        public SubInner() {
            super();
            SuperOuter so = Sub.this.new SuperOuter();
            so.test();
        }
    }
    
    
    public Sub() { super(); }
}
