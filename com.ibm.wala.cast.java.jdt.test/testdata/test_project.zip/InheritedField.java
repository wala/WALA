public class InheritedField {
    
    public static void main(String[] args) {
        InheritedField if1 = new InheritedField();
        B b = new B();
        b.foo();
        b.bar();
    }
    
    public InheritedField() { super(); }
}

class A {
    protected int value;
    
    public A() { super(); }
}

class B extends A {
    
    public void foo() { value = 10; }
    
    public void bar() { this.value *= 2; }
    
    public B() { super(); }
}
