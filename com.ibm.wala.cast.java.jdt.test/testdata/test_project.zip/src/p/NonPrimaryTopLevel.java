package p;

public class NonPrimaryTopLevel {
    public static void main(String[] args) {
	NonPrimaryTopLevel nptl= new NonPrimaryTopLevel();
	Foo f = new Foo();
    }
}

class Foo {
    
}