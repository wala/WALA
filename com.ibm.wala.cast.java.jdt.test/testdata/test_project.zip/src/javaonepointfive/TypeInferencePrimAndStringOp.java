package javaonepointfive;

public class TypeInferencePrimAndStringOp {
  public static void main(String[] args) {
    int a = 2;
    String result = "a" + a;
  }
}

