abstract class PrimitiveWrapper {
    
    abstract public void setIntValue(int i);
    
    abstract public int intValue();
    
    abstract public boolean equals(Object o);
    
    public PrimitiveWrapper() { super(); }
}

final class IntWrapper extends PrimitiveWrapper {
    private int val;
    
    public IntWrapper(int val) {
        super();
        this.val = val;
    }
    
    public int intValue() { return val; }
    
    public void setIntValue(int i) { this.val = i; }
    
    public boolean equals(Object o) {
        return o instanceof IntWrapper && ((IntWrapper) o).val == val;
    }
}

public class MiniaturSliceBug {
    
    public void validNonDispatchedCall(IntWrapper wrapper) {
        wrapper.setIntValue(3);
        assert wrapper.intValue() == 3;
        wrapper.equals(wrapper);
    }
    
    public static void main(String[] args) {
        new MiniaturSliceBug().validNonDispatchedCall(new IntWrapper(-1));
    }
    
    public MiniaturSliceBug() { super(); }
}
