public class CastFromNull {
    
    public static void main(String[] args) {
        new CastFromNull();
        Object x = (Object) null;
        String y = (String) null;
    }
    
    public CastFromNull() { super(); }
}
