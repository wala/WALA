public class InnerClassA {
    int a_x;
    
    public static void main(String[] args) {
        InnerClassA a = new InnerClassA();
        AA aa = a.new AA();
        AB ab = aa.makeAB();
        a.a_x = 5;
        int myx = ab.getA_X_from_AB();
        System.out.println(myx);
        int myx2 = ab.getA_X_thru_AB();
        System.out.println(myx2);
        aa.doSomeCrazyStuff();
    }
    
    public int getA_X() { return a_x; }
    
    class AA {
        int a2a_var;
        
        public AB makeAB() { return InnerClassA.this.new AB(); }
        
        public void doSomeCrazyStuff() {
            AB ab = InnerClassA.this.new AB();
            AB.ABSubA absuba = ab.new ABSubA();
            absuba.aba_x = 7;
            AB.ABA.ABAA abaa2 = ab.new ABA().new ABAA();
            AB.ABA aba = ab.new ABA();
            aba.aba_x = 9;
            AB.ABA.ABAB abab = aba.new ABAB();
            System.out.println(abab.getABA_X());
            AB.ABA.ABAA abaa = absuba.new ABAA();
            int myaba_x = abaa.getABA_X();
            int mya_x = abaa.getA_X();
            System.out.println(myaba_x);
            System.out.println(mya_x);
            this.doMoreWithABSubA(absuba);
        }
        
        private void doMoreWithABSubA(AB.ABSubA absuba) {
            System.out.println(absuba.getA_X());
            AB.ABSubA.ABSubAA absubaa = absuba.new ABSubAA();
            int myaba_x2 = absubaa.getABA_X();
            int mya_x2 = absubaa.getA_X();
            System.out.println(myaba_x2);
            System.out.println(mya_x2);
            AB.ABA.ABAA abaa = absubaa.makeABAA();
            int myaba_x3 = abaa.getABA_X();
            int mya_x3 = abaa.getA_X();
            System.out.println(myaba_x3);
            System.out.println(mya_x3);
        }
        
        public AA() { super(); }
    }
    
    class AB {
        
        public int getA_X_from_AB() { return a_x; }
        
        public int getA_X_thru_AB() { return InnerClassA.this.getA_X(); }
        
        class ABA {
            int aba_x;
            class ABAA {
                
                int getABA_X() { return aba_x; }
                
                int getA_X() { return a_x; }
                
                public ABAA() { super(); }
            }
            
            class ABAB {
                
                int getABA_X() { return aba_x; }
                
                public ABAB() { super(); }
            }
            
            
            public ABA() { super(); }
        }
        
        class ABSubA extends ABA {
            class ABSubAA {
                
                int getABA_X() { return aba_x; }
                
                int getA_X() { return a_x; }
                
                ABAA makeABAA() { return ABSubA.this.new ABAA(); }
                
                public ABSubAA() { super(); }
            }
            
            
            int getA_X() { return a_x; }
            
            public ABSubA() { AB.this.super(); }
        }
        
        
        public AB() { super(); }
    }
    
    
    public InnerClassA() { super(); }
}
