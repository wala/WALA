public class StaticInitializers {
    static class X {
        int x;
        int y;
        
        int sum() { return x + y; }
        
        int diff() { return x + -y; }
        
        public X() { super(); }
    }
    
    private static X x = new X();
    private static X y;
    
    static { y = new X(); }
    
    private int sum() { return x.sum() * y.diff(); }
    
    public static void main(String[] args) {
        StaticInitializers SI = new StaticInitializers();
        SI.sum();
    }
    
    public StaticInitializers() { super(); }
}
