public class AnonymousClass {
    private static interface Foo {
        
        public int getValue();
        
        public int getValueBase();
    }
    
    
    public static void main(String[] args) {
        final Integer base = new Integer(6);
        Foo f =
          new Foo() {
            int value = 3;
            
            public int getValue() { return value; }
            
            public int getValueBase() { return value - base.intValue(); }
        };
        System.out.println(f.getValue());
        System.out.println(f.getValueBase());
        new AnonymousClass().method();
    }
    
    public void method() {
        final Integer base = new Integer(7);
        abstract class FooImpl implements Foo {
            int y;
            
            abstract public int getValue();
            
            FooImpl(int _y) {
                super();
                y = _y;
            }
            
            public int getValueBase() {
                return y + this.getValue() - base.intValue();
            }
        }
        ;
        Foo f =
          new FooImpl(-4) {
            
            public int getValue() { return 7; }
        };
        System.out.println(f.getValue());
        System.out.println(f.getValueBase());
    }
    
    public AnonymousClass() { super(); }
}
