public class ArrayLiteral1 {
    public static void main(String[] args) {
	ArrayLiteral1 al1= new ArrayLiteral1();
	int[] a= new int[] { 0, 1, 2, 3, 5 };
	Object[] b= new Object[] { null, "hi", new Integer(55), new int[] { 3, 1, 4 } };

    }
}