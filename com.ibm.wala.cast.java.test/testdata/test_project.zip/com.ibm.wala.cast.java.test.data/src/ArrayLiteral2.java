public class ArrayLiteral2 {
    public static void main(String[] args) {
	ArrayLiteral2 al2= new ArrayLiteral2();
	int[] x= {};
	int[] y= { 1, 2, 3, 4 };
    }
}
