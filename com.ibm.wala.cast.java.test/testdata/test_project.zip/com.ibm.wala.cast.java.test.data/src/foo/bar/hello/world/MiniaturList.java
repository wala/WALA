package foo.bar.hello.world;

public class MiniaturList {



        public static void main(String[] args) {
        	int a;
            for ( ;; ) {
                            break;
            }
        }
}

