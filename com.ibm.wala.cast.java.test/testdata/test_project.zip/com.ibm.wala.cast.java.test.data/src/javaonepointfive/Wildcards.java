package javaonepointfive;
import java.util.ArrayList;

public class Wildcards {
	public static void printCollection(ArrayList<?> c) {
		// for (Object e : c) {

		// for (Iterator tmp = c.iterator(); tmp.hasNext(); ) {
		// Object e = tmp.next();

		Object e = c.get(0);
		System.out.println(e);
		// }
	}
	public static void printCollection1(ArrayList<? extends Object> c) {
		Object e = c.get(0);
		System.out.println(e);
	}
	public static void printCollection2(ArrayList<? extends String> c) {
		String e = c.get(0);
		System.out.println(e);
	}

	public static void main(String args[]) {
		ArrayList<String> e = new ArrayList<String>();
		e.add("hello");
		e.add("goodbye");
		printCollection(e);
		printCollection1(e);
		printCollection2(e);

		ArrayList<Integer> e3 = new ArrayList<Integer>();
		e3.add(new Integer(123));
		e3.add(new Integer(42));
		printCollection(e3);
		printCollection1(e3);
		
	}
}
