package javaonepointfive;
public class NotSoSimpleEnums {
	public enum Direction {
	    NORTH("nord") { public Direction getOpposite() { return SOUTH; }},
	    EAST("est") { public Direction getOpposite() { return WEST; }},
	    SOUTH("sud") { public Direction getOpposite() { return NORTH; }},
	    WEST("ouest") { public Direction getOpposite() { return EAST; }};
		
	    public abstract Direction getOpposite();
		
		String translation;
		Direction(String translation) {
			this.translation = translation;
		}
		public String getTranslation() {
			return translation;
		}
	}
	
	public static void main(String args[]) {
		System.out.println("never eat shredded wheat");
		System.out.println(Direction.NORTH.translation + " " + Direction.NORTH.getOpposite());
		System.out.println(Direction.EAST.translation + " " + Direction.EAST.getOpposite());
		System.out.println(Direction.SOUTH.translation + " " + Direction.SOUTH.getOpposite());
		System.out.println(Direction.WEST.translation + " " + Direction.WEST.getOpposite());
	}
}

// ENUMS
// * create class that extends Enum
// * convert syntactic sugar:
// 		NORTH("nord")
//   -> public static final Direction NORTH = new Direction("NORTH", 0, "nord");
// * EAST { public Direction getOpposite() { return WEST; }},
//   how done if class final?
// * create $VALUES variable in static initializer
// * create values() and valueOf() function
// * convert constructor(s) to add extra parameters, call to super, AND don't forget about initializers (maybe)

// compiled into something like this:
////Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
////Jad home page: http://www.geocities.com/kpdus/jad.html
////Decompiler options: packimports(3) 
////Source File Name:   SimpleEnums.java
//
//import java.io.PrintStream;
//
//public class SimpleEnums
//{
// public static abstract class Direction extends Enum
// {
//
//     public static Direction[] values()
//     {
//         return (Direction[])$VALUES.clone();
//     }
//
//     public static Direction valueOf(String s)
//     {
//         return (Direction)Enum.valueOf(SimpleEnums$Direction, s);
//     }
//
//     public abstract Direction getOpposite();
//
//     public String getTranslation()
//     {
//         return translation;
//     }
//
//     public static final Direction NORTH;
//     public static final Direction EAST;
//     public static final Direction SOUTH;
//     public static final Direction WEST;
//     String translation;
//     private static final Direction $VALUES[];
//
//     static 
//     {
//         NORTH = new Direction("NORTH", 0, "nord") {
//
//             public Direction getOpposite()
//             {
//                 return SOUTH;
//             }
//
//         };
//         EAST = new Direction("EAST", 1, "est") {
//
//             public Direction getOpposite()
//             {
//                 return WEST;
//             }
//
//         };
//         SOUTH = new Direction("SOUTH", 2, "sud") {
//
//             public Direction getOpposite()
//             {
//                 return NORTH;
//             }
//
//         };
//         WEST = new Direction("WEST", 3, "ouest") {
//
//             public Direction getOpposite()
//             {
//                 return EAST;
//             }
//
//         };
//         $VALUES = (new Direction[] {
//             NORTH, EAST, SOUTH, WEST
//         });
//     }
//
//     private Direction(String s, int i, String s1)
//     {
//         super(s, i);
//         translation = s1;
//     }
//
// }
//
//
// public SimpleEnums()
// {
// }
//
// public static void main(String args[])
// {
//     System.out.println("never eat shredded wheat");
//     System.out.println((new StringBuilder()).append(Direction.NORTH.translation).append(" ").append(Direction.NORTH.getOpposite()).toString());
//     System.out.println((new StringBuilder()).append(Direction.EAST.translation).append(" ").append(Direction.EAST.getOpposite()).toString());
//     System.out.println((new StringBuilder()).append(Direction.SOUTH.translation).append(" ").append(Direction.SOUTH.getOpposite()).toString());
//     System.out.println((new StringBuilder()).append(Direction.WEST.translation).append(" ").append(Direction.WEST.getOpposite()).toString());
// }
//}
