package javaonepointfive;
public class AnonGeneNullarySimple {

	static interface Ops<E> {
		public E nullary();
	}

	static class StrTripler implements Ops<String> {
		public String nullary() {
			String x = "talk about it ";
			return x+x+x;
		}
	}		

	public static void main(String args[]) {
		
		Ops<String> ops = new StrTripler();
		String globalEconomy = ops.nullary();
		String localEconomy = new StrTripler().nullary();
		System.out.println(globalEconomy+localEconomy);
		
	}
}
