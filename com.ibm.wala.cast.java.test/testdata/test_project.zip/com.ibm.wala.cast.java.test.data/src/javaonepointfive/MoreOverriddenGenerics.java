package javaonepointfive;
public class MoreOverriddenGenerics {
	class Super<T> {
		T x;

		public T get() {
			return x;
		}
	}

	class Sub {//extends Super<Number> {
//		public Object get() {
//			return new Object();
//		} // error: incompatible return type

		public Number get() {
			return null;
		} // overrides
	}
	
	class SubSub extends Sub {
		public Long get() {
			return new Long(6);
		}
	}

}
