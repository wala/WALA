package javaonepointfive;
import java.util.ArrayList;
import java.util.Collection;

public class GenericSuperSink {
	public static void main(String args[]) {
		Collection<? super String> sink;
		Collection<String> cs = new ArrayList<String>();
		cs.add("hello");
		
		sink = new ArrayList<Object>();
		sink.add(cs.iterator().next());
		System.out.println(sink);

		sink = new ArrayList<String>();
		sink.add(cs.iterator().next());
		System.out.println(sink);
	}

}
