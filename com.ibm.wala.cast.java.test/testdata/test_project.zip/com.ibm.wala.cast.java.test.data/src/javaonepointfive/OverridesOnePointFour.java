package javaonepointfive;
public class OverridesOnePointFour {
	static interface Super {
		public Number get();// {
//			return new Integer(11);
//		}
	}
	
	static class Sub implements Super {
		public Long get() {
			return new Long(6);
		}
	}

	public static void main(String args[]) {
		Super sup = new Sub();
		Number x = sup.get();
		System.out.println(x);
	}
}
