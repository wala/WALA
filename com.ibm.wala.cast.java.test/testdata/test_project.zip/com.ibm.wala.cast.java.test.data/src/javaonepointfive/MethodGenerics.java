package javaonepointfive;
import java.util.ArrayList;
import java.util.Collection;

public class MethodGenerics {
	static <T> void fromArrayToCollection(T[] a, Collection<T> c) {
		c.add(a[0]);
	}

	static <T extends String> void foo(String x, T y) {
		x = y;
		System.out.println(x);
	}
	
	public static void main(String args[]) {
		ArrayList<String> list = new ArrayList<String>();
		String array[] = new String[] { "coucou monde", "ciao mondo", "guten tag welt", "hola mundo", "shalom olam" };
		fromArrayToCollection(array, list);
		System.out.println(list);
	}
}
