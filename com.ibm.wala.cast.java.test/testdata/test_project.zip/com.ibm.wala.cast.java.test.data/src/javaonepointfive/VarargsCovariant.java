package javaonepointfive;
public class VarargsCovariant {
	static class A { A hello(int... x) {System.out.println("a hello");return this;} }
	static class B extends A { B hello(int... x) {System.out.println("b hello");return this;} }


	public static void main(String args[]) {
		A a = new B();
		a.hello(3114, 35, 74, 51617054);
	}

}
