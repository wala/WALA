package javaonepointfive;
public class AnonymousGenerics {

	static interface Ops<E> {
		public E nullary();
		public E unary(E x);
	}

	static class StrTripler implements Ops<String> {
		// if has type parameters, find overriding method and 
		// get erasures for all of those types and make a new method
		// that calls this one (with casts). no worries about return values.
		public String unary(String x) {
			return x + x + x;
		}
		public String nullary() {
			String x = "talk about it ";
			return x+x+x;
		}
	}		

	public static void main(String args[]) {
		Ops<String> strQuadrupler = new Ops<String>() {
			public String unary(String x) {
				return x+x+x+x;
			}
			public String nullary() {
				String x = "time to make a move to the global economy ";
				return x+x+x+x;
			}
		};
		System.out.println(strQuadrupler.unary("hi"));
		System.out.println(new StrTripler().unary("hi"));
		
		String globalEconomy = strQuadrupler.nullary();
		System.out.println(globalEconomy);
		
		Ops<String> ops = new StrTripler();
		globalEconomy = ops.nullary();
		System.out.println(globalEconomy);
	}
}
