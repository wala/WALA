package javaonepointfive;
public class SimpleEnums {
	public enum Direction {
	    NORTH,
	    EAST,
	    SOUTH,
	    WEST;

	}

	public static void main(String args[]) {
		System.out.println("never eat shredded wheat");
		System.out.println(Direction.NORTH);
		System.out.println(Direction.EAST);
		System.out.println(Direction.SOUTH);
		System.out.println(Direction.WEST.toString());
	}
}
