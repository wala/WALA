package javaonepointfive;

public class ExplicitBoxingTest {

	public static void main(String[] args) {
		int a = 6;
		a = a + a;
		System.out.println(a);
		Integer useless1 = new Integer(5+6);
		Integer aa = new Integer(a+a);
		int aaa = aa.intValue();
		System.out.println(aaa);

		int b = 6;
		b = b + b;
		System.out.println(b);
		Integer useless2 = 5+6;
		Integer bb = b+b;
		int bbb = bb;
		System.out.println(bbb);
	}
}
