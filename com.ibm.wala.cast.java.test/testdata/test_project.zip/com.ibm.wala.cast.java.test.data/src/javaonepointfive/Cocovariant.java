package javaonepointfive;
public class Cocovariant {
        static class A {
                A foo(String x) { return null; }
        }
        static class B extends A {
                B foo(String x) { return null; }
        }
        static class C extends B {
                C foo(String x) { return null; }
        }
        public static void main(String[] args) {
                C x = new C().foo("");
        }
}
