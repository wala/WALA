package javaonepointfive;
// what IS illegal and we don't have to worry about:
//  "x instanceof E"
//  y = new Q();

interface IGeneric<E> {
	E foo();

	E bar(E x, E y);
}

// Y: "implements IGeneric" (no <E>)
// TOTRY: two arguments
class ConcreteGeneric<Q> implements IGeneric<Q> {
	Q x;

	public Q bar(Q a, Q b) {
		x = a;
		if (b.hashCode() == a.hashCode() || b.toString().equals(a.toString()))
			return a;
		return b;
	}

	public Q foo() {
		return x;
	}
}

class ConcreteGeneric2<Q> extends ConcreteGeneric<Q> {
	Q y;
	public void setFoo(Q a) {
		y = a;
	}
	public Q foo() {
		return y;
	}
}

class MyGeneric<A extends Object, B extends IGeneric<A>> {
	A a;
	B b; // TODO: check field type
	public MyGeneric(A a, B b) { // TODO: check parameter type
		this.a = a;
		this.b = b;
	}
	public A doFoo() { // TODO: check return value type
		return b.foo();
	}
	public B getB() {
		return b;
	}
}

public class CustomGenericsAndFields {
	static ConcreteGeneric2<String> cg2 = new ConcreteGeneric2<String>();

	static public ConcreteGeneric2<String> cg2WithSideEffects() {
		System.out.println("look at me! I'm a side effect!");
		return cg2;
	}

	public static void main(String args[]) {
		// Simple: concrete generic
		
		ConcreteGeneric<String> absinthe = new ConcreteGeneric<String>();
		IGeneric<String> rye = absinthe;
		String foo = rye.bar("hello", "world");
		System.out.println(absinthe.foo() + foo);

		/////////////////////////////

		String thrownaway = cg2.bar("a","b");
		cg2.setFoo("real one");
		MyGeneric<String,ConcreteGeneric2<String>> mygeneric = new MyGeneric<String,ConcreteGeneric2<String>>("useless",cg2);
		String x = mygeneric.doFoo();
		System.out.println(x);
		String y = cg2.x;
		System.out.println(mygeneric.getB().y);
		System.out.println(mygeneric.b.y); // TODO: fields are going to be a pain... watch out for Lvalues in context?
		cg2.x = null;
		cg2.x = "hello";

//		mygeneric.getB().y+="hey"; // TODO: this is going to be a MAJOR pain...
		String real_oneheyya = (((cg2WithSideEffects().y))+="hey")+"ya"; // TODO: this is going to be a MAJOR pain...
		System.out.println(real_oneheyya);
	}
}
