package javaonepointfive;

class Alef {
	void foo(String... args) {
		System.out.println("var args not overridden");
	}
}
class Bet extends Alef {
	void foo(String a, String b) {
		System.out.println("non-varargs overrides varargs");
	}
}
class Alpha {
	void foo(String a, String b) {
		System.out.println("non-varargs not overridden");
	}
}
class Beta extends Alpha {
	void foo(String... args) {
		System.out.println("varargs overrides non-varargs");
	}
}


////

class VarityTestSuper {
	void bar(String... args) {}
}
class VarityTestSub extends VarityTestSuper {
	void bar(String... args) {}
}

public class VarargsOverriding {
	public static void main(String args[]) {
		Bet b = new Bet();
		Alef a = b;
		a.foo("hello", "world");
		b.foo("hello", "world");

		Beta bb = new Beta();
		Alpha aa = bb;
		aa.foo("hello", "world");
		bb.foo("hello", "world");

		VarityTestSuper x = new VarityTestSub();
		x.bar("Hello", "world", "howareya");
	}
}
