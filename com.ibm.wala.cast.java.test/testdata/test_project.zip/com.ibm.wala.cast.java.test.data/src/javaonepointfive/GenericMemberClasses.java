package javaonepointfive;
import java.util.Iterator;


public class GenericMemberClasses<T> 
{
    protected class A implements Iterator<T> 
    {
    	T x = null;
        private int localChangeID;
		public boolean hasNext() {
			return ( localChangeID == 5 );
		}

		public T next() {
			localChangeID = 5;
			return x;
		}

		public void remove() {
		}
    }
    public static void main(String args[]) {
    	Object x = new GenericMemberClasses<Object>().new A().next();
    	System.out.println(x);
    }
}